package com.csis3475;

public class UndergraduateStudent extends Student {

	public UndergraduateStudent(int studentId, String studentLastName) {
		super(studentId, studentLastName);
		setTuition();
		// TODO Auto-generated constructor stub
	}

	@Override
	void setTuition() {
		// TODO Auto-generated method stub
		super.annualTuition = 4000.00 * 2;
	}

}
