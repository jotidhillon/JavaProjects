package com.csis3475;

public class StudentDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Student[] students = new Student[6];
		
		students[0] = new UndergraduateStudent(101, "Smith");
		students[1] = new GraduateStudent(102, "Samuel");
		students[2] = new StudentAtLarge(103, "Mason");
		students[3] = new UndergraduateStudent(104, "Kim");
		students[4] = new GraduateStudent(105, "Wilson");
		students[5] = new StudentAtLarge(106, "Shah");
		
		for (Student student : students) {
			System.out.println(student);
			System.out.println();
		}
	}

}
