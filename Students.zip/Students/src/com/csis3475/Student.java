package com.csis3475;

public abstract class Student {

	int studentId;
	
	String studentLastName;
	
	double annualTuition;

	public Student(int studentId, String studentLastName) {
		super();
		this.studentId = studentId;
		this.studentLastName = studentLastName;
	}

	public int getStudentId() {
		return studentId;
	}

	public void setStudentId(int studentId) {
		this.studentId = studentId;
	}

	public String getStudentLastName() {
		return studentLastName;
	}

	public void setStudentLastName(String studentLastName) {
		this.studentLastName = studentLastName;
	}

	public double getAnnualTuition() {
		return annualTuition;
	}

	public void setAnnualTuition(double annualTuition) {
		this.annualTuition = annualTuition;
	}
	
	abstract void setTuition();

	@Override
	public String toString() {
		return "Student [studentId=" + studentId + ", studentLastName=" + studentLastName + ", annualTuition="
				+ annualTuition + "]";
	}
	
	
}
