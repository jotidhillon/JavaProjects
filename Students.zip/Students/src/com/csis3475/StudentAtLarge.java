package com.csis3475;

public class StudentAtLarge extends Student {

	public StudentAtLarge(int studentId, String studentLastName) {
		super(studentId, studentLastName);
		setTuition();
		// TODO Auto-generated constructor stub
	}

	@Override
	void setTuition() {
		// TODO Auto-generated method stub
		super.annualTuition = 2000.00 * 2;

	}

}
