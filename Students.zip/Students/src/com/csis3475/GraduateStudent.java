package com.csis3475;

public class GraduateStudent extends Student {

	public GraduateStudent(int studentId, String studentLastName) {
		super(studentId, studentLastName);
		setTuition();
		// TODO Auto-generated constructor stub
	}

	@Override
	void setTuition() {
		// TODO Auto-generated method stub
		super.annualTuition = 6000.00 * 2;
	}

}
