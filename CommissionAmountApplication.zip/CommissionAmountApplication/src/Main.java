//Joti Dhillon
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {

        //Scanner for the input
        Scanner input = new Scanner(System.in);
        //Strings for the employeeName, employeeType, managerType, productType
        //double variables for the salesAmount and commissionAmount
        String employeeName;
        String employeeType;
        String managerType;
        String productType;
        double salesAmount;
        double commissionAmount = 0;
        System.out.println("Enter name of the Employee ");
        employeeName = input.nextLine();
        System.out.println("Enter the type of Employee, R for regular, C for Contractual, P for Part-time ");
        employeeType = input.nextLine();
        System.out.println("Enter the type of the item, W for washing machine, R for refrigerator and M for music system ");
        productType = input.nextLine().toUpperCase();
        System.out.println("Is the employee a Manager, Y for yes and N for no: ");
        managerType = input.nextLine().toUpperCase();
        System.out.println("Enter the sales amount ");
        salesAmount = input.nextDouble();
        commissionAmount = totalCommission(employeeName, employeeType, productType, managerType, salesAmount);
    }

    //public static double method for the commission amounts with if else statements
    public static double totalCommission(String employeeName, String employeeType, String productType, String managerType, double salesAmount) {
        double commissionAmount = 0;

        if ((managerType.equals("Y"))) {
            commissionAmount = (salesAmount * 0.08);
        } else {

            if (employeeType.equals("R")) {
                commissionAmount = (salesAmount * 0.15);
            } else if (employeeType.equals("P") && productType.equals("W")) {
                if (salesAmount > 10000) {
                    commissionAmount = (salesAmount * 0.10);
                } else {
                    commissionAmount = (salesAmount * 0.05);
                }
            } else if (employeeType.equals("P") && productType.equals("R")) {
                if (salesAmount > 10000) {
                    commissionAmount = (salesAmount * 0.08);
                } else {
                    commissionAmount = (salesAmount * 0.05);
                }
            } else if (employeeType.equals("P") && productType.equals("M")) {
                commissionAmount = (salesAmount * 0.10);
            } else if (employeeType.equals("C") && productType.equals("W")) {
                if (salesAmount > 10000) {
                    commissionAmount = (salesAmount * 0.12);
                } else {
                    commissionAmount = (salesAmount * 0.08);
                }
            } else if (employeeType.equals("C") && productType.equals("R")) {
                if (salesAmount > 10000) {
                    commissionAmount = (salesAmount * 0.10);
                } else {
                    commissionAmount = (salesAmount * 0.05);
                }
            } else if (employeeType.equals("C") && productType.equals("M")) {
                commissionAmount = (salesAmount * 0.12);
            }
        }
        //printing out final result with the commissionAmount
        System.out.println("Hello " + employeeName + " your total commission is $" + (String.format("%.2f", commissionAmount)));
        return commissionAmount;
    }
}