package com.csis3475;

public class ArrayBackwardsDisplay {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int[] array = {1,2,3,4,5,6,7};
		displayBackwards(array, 2, 5);
		
	}
	public static void displayBackwards(int[] array, int start, int end) {
		if (start <= end) {
			System.out.print(array[end] + " ");
			displayBackwards(array, start, end - 1);
		}
	}

}
