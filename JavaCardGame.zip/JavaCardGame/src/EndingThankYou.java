public class EndingThankYou {
    public static void thankyouMessage() {
        //for loop for the Thank you message with *'s that are incrementing
        System.out.println("Thank you for playing");
        for (int i = 0; i<=5; i++)
        {
            for (int j= 0; j<=i; j++) {
                System.out.print("*");
            }
            //Outputs the Thank you for playing message
            System.out.println("Thank you for playing");
        }
        //for loop for the *'s decrementing for the Thank you message
        for (int i = 4; i >= 0; i--) {
            // System.out.print("*");
            for (int j = 0; j <=i; j++)
            {
                System.out.print("*");
            }
            //Outputs the Thank you for playing message
            System.out.println("Thank you for playing");
        }

    }
}
