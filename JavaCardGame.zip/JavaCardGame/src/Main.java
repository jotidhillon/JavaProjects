public class Main {
    public static void main(String[] args) {
        //instance methods for RandomNumber class and EndingThankYou class
        RandomNumber.newCard();
        EndingThankYou.thankyouMessage();
    }
}