//Joti Dhillon


import java.util.Random;
import java.util.Scanner;

public class RandomNumber {
    //private static to share data for num1, num2 and num3 across instances of the RandomNumber class
    private static int num1;
    private static int num2;

    private static int num3;

    //public static int method for numberGeneration
    public static int numberGeneration() {
        //Computer move generation to generate random numbers from 1 to 21
        Random randomNum = new Random();
        //first num1 randomNum generated for the Computer move
        num1 = 1 + randomNum.nextInt(21);
        //Output for the Computer score
        System.out.println("The computer's score is " + num1);
        return 0;
    }

    //public static void newCard method
    public static void newCard() {
        boolean flag = true;
        //Scanner for the input scan
        Scanner scan = new Scanner(System.in);

        //random number generation for 1 to 11 to represent users move
        Random randomNum = new Random();
        char input;
        //num2 randomNum generated for the user move
        while (true) {
            num2 = 1 + randomNum.nextInt(11);
            int sum = num2;

            //Output for num2
            System.out.println("The card is " + num2);
            System.out.println("Your total is " + num2);


            //while loop for the looping for the num2 greater than 0 while count greater than 1
            while (true) {
                //Output for the card y for Yes or n for No
                System.out.println("Do you want another card?, y for Yes and n for No");
                //char input for the 'y' or 'n'
                input = scan.next().charAt(0);
                //if statement when input == 'y' and sum less than or equal to 21
                if (input == 'y' && sum <= 21) {
                    //Output for the input
                    System.out.println(input);
                    //num3 card being taken out
                    int num3 = 1 + randomNum.nextInt(11);
                    //Output for the num3 card
                    System.out.println("The card is " + num3);
                    sum += num3;

                    //Output for the total sum
                    System.out.println("Your total is " + sum);
                }
                //else if statement if input would be 'n'
                else if (input == 'n') {
                    numberGeneration();
                    //nested if statement if sum > num1 and input == 'n'
                    if ((sum > num1)) {
                        System.out.println("You win");
                        break;
                        //else if statement for num1 == sum and if input == 'n'
                    } else if ((num1 == sum)) {
                        System.out.println("It's a tie");
                        break;
                        //else if statement if sum < num1 and input == 'n'
                    } else if ((sum < num1)) {
                        // sum = sum + num3;
                        System.out.println("You lose");
                        break;
                    }

                    //else statement to print the losing statement
                } if (sum > 21) {
                    System.out.println("You lose");

                    //while loop if sum is greater to ask whether to play again
                    break;
                }
            }
            //}
            System.out.println("Do you want to play again?, y for Yes and n for No");
            input = scan.next().charAt(0);
            //if statement if input == 'n'
            if (input == 'n') {
                break;
            }
        }
    }
}