//Joti Dhillon

//imports the java scanner

import java.util.Scanner;

public class Main {
    private static Scanner input;

    public static void main(String[] args) {
        input = new Scanner(System.in);
        int unit = 0;
        int days = 0;
        //printing out the message to ask how many units
        while (true) {
            System.out.println("How many units");
            //input for unit
            unit = input.nextInt();
            if (unit > 0) {
                break;
            } else {
                //message for the unit required to be above 0
                System.out.println("Needs to be above 0");
            }
        }
        //method call for the totalAmount method
        totalAmount(unit);
        input.close();
    }

    //method for the Units that would be computing the unit for the totalBill with charges per unit
    public static double units(int unit) {
        double totalBill = 0;
        //Calculations for the totalBill
        if (unit > 500) {
            totalBill += 5.00 * (unit - 500);
            unit -= (unit - 500);
        }
        if (unit > 200) {
            totalBill += 3.5 * (unit - 200);
            unit -= (unit - 200);
        }
        totalBill += unit * 2.5;

        return totalBill;
    }

    //method for the totalAmount with parameters
    public static void totalAmount(int unit) {

        //initializes inputAns
        int inputAns;
        //initializes totalBill and finalBill
        double totalBill = 0;
        double finalBill = 0;
        //while loop for the unit greater than 0
        if (unit > 0) {
            while (true) {
                //Message to ask whether the days are within 15 days
                System.out.println("Can the consumer pay within 15 days? 1 for yes or 0 for no");
                //takes the input for 1 (Yes) or 0 (No)
                inputAns = input.nextInt();
                if (inputAns == 1 || inputAns == 0) {
                    break;
                } else {
                    System.out.println("Invalid Input");
                }
            }
            if ((inputAns == 1)) {
                //method call for the Units method
                totalBill = units(unit);

                System.out.println("Yes");
                //initializing discount variable
                double discount = 0.1; //qualified for 10% off
                finalBill = totalBill * (1 - discount);
                //Prints the amount with the discount amount
                System.out.println("Amount $" + String.format("%.2f", totalBill) + " With Discount Amount $" + String.format("%.2f", finalBill));

            } else if ((inputAns == 0)) {
                totalBill = units(unit);
                System.out.println("No");
                //initializing surcharge variable
                double surcharge = 0.05; //surcharge included for 5%
                finalBill = (totalBill * (1 + surcharge));

                //Prints the amount with the surcharge amount
                System.out.println("Amount $" + String.format("%.2f", totalBill) + " With Surcharge Amount $" + String.format("%.2f", finalBill));
            }
        }
    }
}