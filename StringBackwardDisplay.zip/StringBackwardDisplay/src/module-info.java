/**
 * 
 */
/**
 * 
 */
module StringBackwardDisplay {
}