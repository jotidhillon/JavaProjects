package com.csis3475;

import java.util.Scanner;

public class StringBackwardDisplay {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String inputString = getUserInput();
		displayStringBackward(inputString);
	}
	
	public static String getUserInput() {
		Scanner input = new Scanner(System.in);
		System.out.print("Enter a string ");
		return input.nextLine();
		
	}
	public static void displayStringBackward(String str) {
	        displayStringBackwardHelper(str, str.length() - 1);
	    }

	private static void displayStringBackwardHelper(String str, int index) {
	        if (index >= 0) {
	            System.out.print(str.charAt(index));
	            displayStringBackwardHelper(str, index - 1);
	        }
	    }
}
