public class Main {
    public static void main(String[] args) {
        //method call for the newRandom method
        newRandom();
    }
    //Lab 2
    //Create a 5 by 5 two dimensional array.
    //Fill the array with random numbers from 1 to 25.
    //Make sure that the numbers will not repeat.
    //Output your result.

    //public static void newRandom method
    public static void newRandom() {


        //declare the 2d array
        int[][] ar1 = new int[5][5];

        //nested for loop to create the 2d array
        for (int i = 0; i < ar1.length; ++i) {
            for (int j = 0; j < ar1[i].length; ++j) {
                //initiate variable random_num
                int random_num;
                //while loop to check whether everything in the brackets would be true
                while (true) {
                    //Randomization of numbers through the random_num variable with Math.random()
                    random_num = 1 + (int) (Math.random() * 25);
                    //initialized boolean variable to check the numbers in the array for similar numbers
                    boolean checkNum = false;
                    //nested for loop to check the numbers in the array
                    for (int k = 0; k < ar1.length; k++) {
                        for (int l = 0; l < ar1[k].length; l++) {
                            //if statement to check the array whether it is equal to random_num
                            if (ar1[k][l] == random_num) {
                                //if similar number is true then break
                                checkNum = true;
                                break;
                            }
                        }
                        //if statement to check if number is the same
                        if (checkNum) {
                            break;
                        }
                    }
                    //if statement to check if number is not the same
                    if (!checkNum) {
                        break;
                    }
                }
                //array initialized to random_num
                ar1[i][j] = random_num;
            }
        }
        //nested for loop to print out the array of numbers
        for (int i = 0; i < ar1.length; i++) {
            for (int j = 0; j < ar1[i].length; j++) {
                //printing out the array with tabs for spacing
                System.out.print(ar1[i][j] + "\t");
            }
            System.out.println();
        }

    }
}